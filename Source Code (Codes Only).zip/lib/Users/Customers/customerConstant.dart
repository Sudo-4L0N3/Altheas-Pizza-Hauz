import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFe1eaf1); //primary color of our website
const kSecondaryColor = Color(0xFFfe5722); //secondary color
const kPrimaryColorButton = Color.fromARGB(255, 165, 53, 81);
const kMaxWidth = 1232.0;
const kPadding = 20.0;
